package basePackage.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;

@Repository
public class ShiftDao extends JdbcDaoSupport
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}
	
	public void addShift(String staff_ID, String start_time, String end_time){
		String query = "INSERT INTO shifts(staff_ID, start_time, end_time) VALUES (?, ?, ?)";
		
		int result = jdbcTemplate.update(query, staff_ID, start_time, end_time);
		
		if (result > 0) {
			System.out.println(result + " shift added to database");
		}
	}
	
}
