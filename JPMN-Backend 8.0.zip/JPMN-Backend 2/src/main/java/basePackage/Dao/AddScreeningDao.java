package basePackage.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import java.util.HashMap;
import java.util.Map;

@Repository
public class AddScreeningDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	/**
	This method can fuck off!  //Julius           (But I fixed it!)
	 */
	public void addScreenings(String title, String studio, String screening_date, String saloon){

		// If a space (" ") was added from frontend it will be replaced by the phrase "WHITESPACEHEREX".
		// This phrase is raplaced back with a space here so that the String takes its original form with spaces included
		// (This was done to fix an annoying bug where the program simply refused to take in spaces in Strings...)
		String titleSpaceFixed = title.replace("WHITESPACEHEREX", " ");
		String studioSpaceFixed = studio.replace("WHITESPACEHEREX", " ");
		String screening_dateSpaceFixed = screening_date.replace("WHITESPACEHEREX", " ");
		String saloonSpaceFixed = saloon.replace("WHITESPACEHEREX", " ");
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("add_screening");
		
		Map<String, String> inParameters = new HashMap<>();

		inParameters.put("title", titleSpaceFixed);
		inParameters.put("studio", studioSpaceFixed);
		inParameters.put("screening_date", screening_dateSpaceFixed);
		inParameters.put("saloon", saloonSpaceFixed);
		
		SqlParameterSource in = new MapSqlParameterSource(inParameters);

		simpleJdbcCall.execute(in);
	}

}
