package basePackage.jpmnbackend;

import basePackage.Dao.DeleteStaffDao;
import basePackage.Service.*;
import basePackage.dataBaseClasses.Shift;
import basePackage.dataBaseClasses.Staff;
import basePackage.dataBaseClasses.Upcomming_screening;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@SpringBootApplication
@ComponentScan(basePackages = "basePackage")


//Den här ska vara i domain-klassen som håller alla endpoints
@RestController
public class JpmnBackendApplication {
    
    public static ApplicationContext context;

    @Autowired
    CustomerService customerService;
    
    @Autowired
    DeleteStaffService deleteStaffService;
    
    @Autowired
    AddScreeningService addScreeningService;
    

    public static void main(String[] args) {
        //SpringApplication.run(JpmnBackendApplication.class, args);
        
        
        //Skriver ut all info om customer_ID 1 från customers i databasen
        context = SpringApplication.run(JpmnBackendApplication.class, args);
    
        DeleteStaffService deleteStaffService = context.getBean(DeleteStaffService.class);

        CustomerService customerService = context.getBean(CustomerService.class);
        StaffService staffService = context.getBean(StaffService.class);
        AddScreeningService screeningService = context.getBean(AddScreeningService.class);

        //System.out.println(customerService.getCustomerById(1));
        
    
        /* ArrayList<Customer> copy = customerService.getAllCustomers();
        
        for (int i = 0; i < copy.size(); i++){
            System.out.println(copy.get(i));
            System.out.println("");
        }*/
        
        //System.out.println(customerService.getAllCustomers().get(1));
       
        //Försök att stoppa in en ny customer
        //Customer Arnold = new Customer(5,"'Arnold Schwarzenegger'", "'bigaustiraman@fatgains.com'", "'5663378744005202'", "12'", "'24'");
        //customerService.insertCustomer(Arnold);
        
        
        //fel import, ändrade till Spring
        //.getBean gav error tills jag prövade de olika
        //context.getBean(Class<T>, object.. objects )
        
    
        //System.out.println(customerService.getCustomerById(1));
        
        /*
        SpringApplication.run(JpmnBackendApplication.class, args);
    
        CustomerService customerService = SpringApplication.run(JpmnBackendApplication.class, args).getBean(CustomerService.class);
        //CustomerService customerService = context.getBean(CustomerService.class);

        Customer Arnold = new Customer(2,"Arnold Schwarzenegger", "bigaustiraman@fatgains.com", "5663378744005202", "12", "12");
        //customerService.insertCustomer(Arnold);
        //System.out.println(customerService.;);
        
        customerService.getCustomerById(2);
        System.out.println(customerService.getCustomerById(2));


        // Problemet nu: Våran syntax är säkert fel, exakt hur fixar vi våran DAO klass?

        // Få våra stored procedures i MySQL att nås från IntelliJ
        // Hur vet vi ifall application.properties fungerar?
        */
    }
    
    @GetMapping ("/hello")
    public String testConnection(@RequestParam(value = "name", defaultValue = "error") String name){
        name = "The connection " + name;
        return name;
    }
    //POTENTIELL LYXFUNKTION, IF-SATS. SOM PRINTAR UT OM STAFF_ID INTE MATCHAR
    @GetMapping ("/getStaffByID")
    public String getStaffById(@RequestParam(value = "staff_ID", defaultValue = "incorrect input") String staff_id){
        StaffService staffService = context.getBean(StaffService.class);
        staff_id = String.valueOf(staffService.getStaffById(Integer.parseInt(staff_id)));
        return staff_id;
    }
    
    @GetMapping ("/getAllStaff")
    public String getAllStaff(){
        StaffService staffService = context.getBean(StaffService.class);
        ArrayList allStaff = staffService.getAllStaff();
        //String returnable = allStaff.toString();
        //String returnable = "";
        
        ArrayList<String> allStaffString = new ArrayList<>();
        
        for (int i = 0; i < allStaff.size(); i++){
            allStaffString.add(allStaff.get(i).toString());
            //returnable += i + "\n";
        }
    
        String returnable = allStaffString.toString();
        
        System.out.println("TEST\n" + returnable);
        return returnable;
    }
    
    @GetMapping("/addStaff")
    public String addStaff(@RequestParam(value = "valuesAsCSV", defaultValue = "Incomplete statement") String valuesAsCSV){
        
        String[] separatedValuesStaff = valuesAsCSV.split(",");
        
        Staff staff = new Staff(separatedValuesStaff[1], separatedValuesStaff[2], separatedValuesStaff[3], separatedValuesStaff[4], separatedValuesStaff[5]);
        StaffService staffService = context.getBean(StaffService.class);
        staffService.insertStaff(staff);
        
        return staff.toString();
    }
    
    @GetMapping("/addShift")
    public String addShift(@RequestParam(value = "valuesAsCSV", defaultValue = "Incomplete statement") String valuesAsCSV){
        
        String[] separatedValuesShift = valuesAsCSV.split(",");
        
        Shift shift = new Shift(separatedValuesShift[1], separatedValuesShift[2], separatedValuesShift[3]);
        ShiftService shiftService = context.getBean(ShiftService.class);
        shiftService.addShift(shift);
        
        return shift.toString();
    }
    
    //Error 404, 405, 500
    //Pröva skapa en domain-klass som har samtliga endpoints i sig, eller en rest-controller-klass
    @DeleteMapping ("/deleteStaffById")
    public void deleteStaffById(@RequestParam(value = "s_ID", defaultValue = "incorrect input") String staff_id) {
        deleteStaffService.deleteStaff(staff_id);
    }
    
    @RequestMapping ("/addScreening")
    public void addScreening(@RequestParam(value = "valuesAsCSV", defaultValue = "incorrect input") String valuesAsCSV){
        String[] separatedValues = valuesAsCSV.split(",");

        for (int i = 0; i < separatedValues.length; i++){  // TESTING!!!!!!!!!!!!!!!!!!!!!!!!!!
            System.out.println(separatedValues[i]);
        }
    
        //Upcomming_screening upcomming_screening = new Upcomming_screening(separatedValues[1], separatedValues[2], separatedValues[3], separatedValues[4]);
        //AddScreeningService addScreeningService = context.getBean(AddScreeningService.class);
        
        addScreeningService.addScreening(separatedValues[1], separatedValues[2], separatedValues[3], separatedValues[4]);
        
    }
}