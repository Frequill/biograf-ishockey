package basePackage.Service;

import basePackage.Dao.CustomerDao;
import basePackage.dataBaseClasses.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Repository
@Service
public class CustomerService {

    @Autowired
    CustomerDao customerDao;

    public void insertCustomer(Customer customer){
        customerDao.insertCustomer(customer.getCustomer_name(), customer.getCustomer_email(), customer.getSalt1(), customer.getCreditcard_number(), customer.getSalt2());
    }
    
    public Customer getCustomerById(int customer_ID){
        return customerDao.getCustomerById(String.valueOf(customer_ID));
    }
    
    public ArrayList<Customer> getAllCustomers(){
        return (ArrayList<Customer>) customerDao.getAllCustomers();
    }
}
