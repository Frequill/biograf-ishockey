package basePackage.Dao;

import basePackage.dataBaseClasses.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
@Repository
public class CustomerDao extends JdbcDaoSupport
{

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @PostConstruct
    
    private void initialize(){
        setJdbcTemplate(jdbcTemplate);
    }
    
    public void insertCustomer(String customer_name, String customer_email, String salt1, String creditcard_number, String salt2){
        
        String query = "INSERT INTO customers(customer_name, customer_email, salt1, creditcard_number, salt2) VALUES ?, ?, ?, ?, ?)";
        
        int result = jdbcTemplate.update(query, customer_name, customer_email, salt1, creditcard_number, salt2);
        
        if (result > 0){
            System.out.println(result + " customer added to database");
        }
    }
    
    public Customer getCustomerById(String id){
        String query = "SELECT * FROM customers WHERE customer_ID = ?";
        
        Customer customer = jdbcTemplate.queryForObject(query, new RowMapper<Customer>() {
            @Override
            public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
                Customer cus = new Customer(rs.getInt("customer_ID"),
                    rs.getString("customer_name"),
                    rs.getString("customer_email"),
                    rs.getString("salt1"),
                    rs.getString("creditcard_number"),
                    rs.getString("salt2"));
                
                    return cus;
                }
        }, id);
        
        return customer;
    }
    
    public List<Customer> getAllCustomers(){
        String query = "SELECT * FROM customers";
        
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
        List<Customer> customerList = new ArrayList<>();
        
        for (Map<String, Object> row: rows){
            Customer customer = new Customer((long)row.get("customer_ID"),
                    (String)row.get("customer_name"),
                    (String)row.get("customer_email"),
                    (String)row.get("salt1"),
                    (String)row.get("creditcard_number"),
                    (String)row.get("salt2"));
            customerList.add(customer);
        }
        
        return customerList;
    }
    
    /*public void insertCustomer(String name, String email_address, String credit_card_nr){
        String query = "CALL biograf.add_customer('" + name + "', '" + email_address + "', '" + credit_card_nr + "');";
        int result = jdbcTemplate.update(query);

        if (result > 0){
            System.out.println("Customer successfully added!");
        } else {
            System.out.println("Something went wrong...");
        }
    }*/

    /*public void selectAllCustomers(){
        String query = "SELECT * FROM customers;";
        int result = jdbcTemplate.update(query);

        if (result > 0){
            System.out.println("All customers: \n" + result);
        } else {
            System.out.println("We have encountered an error!");
        }
    }*/
}
