package basePackage.jpmnbackend;

import basePackage.Service.CustomerService;
import basePackage.Service.StaffService;
import basePackage.dataBaseClasses.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.stream.Collectors;

@SpringBootApplication
@ComponentScan(basePackages = "basePackage")

@RestController
public class JpmnBackendApplication {
    
    public static ApplicationContext context;

    @Autowired
    CustomerService customerService;

    public static void main(String[] args) {
        //SpringApplication.run(JpmnBackendApplication.class, args);
        
        //Skriver ut all info om customer_ID 1 från customers i databasen
        context = SpringApplication.run(JpmnBackendApplication.class, args);

        CustomerService customerService = context.getBean(CustomerService.class);
        StaffService staffService = context.getBean(StaffService.class);

        //System.out.println(customerService.getCustomerById(1));

        System.out.println(staffService.getStaffById(1));
    
        /* ArrayList<Customer> copy = customerService.getAllCustomers();
        
        for (int i = 0; i < copy.size(); i++){
            System.out.println(copy.get(i));
            System.out.println("");
        }*/
        
        //System.out.println(customerService.getAllCustomers().get(1));
       
        //Försök att stoppa in en ny customer
        //Customer Arnold = new Customer(5,"'Arnold Schwarzenegger'", "'bigaustiraman@fatgains.com'", "'5663378744005202'", "12'", "'24'");
        //customerService.insertCustomer(Arnold);
        
        
        //fel import, ändrade till Spring
        //.getBean gav error tills jag prövade de olika
        //context.getBean(Class<T>, object.. objects )
        
    
        //System.out.println(customerService.getCustomerById(1));
        
        /*
        SpringApplication.run(JpmnBackendApplication.class, args);
    
        CustomerService customerService = SpringApplication.run(JpmnBackendApplication.class, args).getBean(CustomerService.class);
        //CustomerService customerService = context.getBean(CustomerService.class);

        Customer Arnold = new Customer(2,"Arnold Schwarzenegger", "bigaustiraman@fatgains.com", "5663378744005202", "12", "12");
        //customerService.insertCustomer(Arnold);
        //System.out.println(customerService.;);
        
        customerService.getCustomerById(2);
        System.out.println(customerService.getCustomerById(2));


        // Problemet nu: Våran syntax är säkert fel, exakt hur fixar vi våran DAO klass?

        // Få våra stored procedures i MySQL att nås från IntelliJ
        // Hur vet vi ifall application.properties fungerar?
        */
    }
    
    @GetMapping ("/hello")
    public String testConnection(@RequestParam(value = "name", defaultValue = "error") String name){
        name = "Hello and welcome, " + name;
        return name;
    }
    //POTENTIELL LYXFUNKTION, IF-SATS. SOM PRINTAR UT OM STAFF_ID INTE MATCHAR
    @GetMapping ("/getStaffByID")
    public String getStaffById(@RequestParam(value = "staff_ID", defaultValue = "incorrect input") String staff_id){
        StaffService staffService = context.getBean(StaffService.class);
        staff_id = String.valueOf(staffService.getStaffById(Integer.parseInt(staff_id)));
        return staff_id;
    }
    
    @GetMapping ("/getAllStaff")
    public String getAllStaff(@RequestParam(value = "allStaff", defaultValue = "incorrect something") ArrayList<Staff> allStaff){
        StaffService staffService = context.getBean(StaffService.class);
        allStaff = staffService.getAllStaff();
        //String returnable = allStaff.toString();
        //String returnable = "";
        
        ArrayList<String> allStaffString = new ArrayList<>();
        
        for (int i = 0; i < allStaff.size(); i++){
            allStaffString.add(allStaff.get(i).toString());
            //returnable += i + "\n";
        }
    
        String returnable = allStaffString.toString();
        
        System.out.println("TEST\n" + returnable);
        return returnable;
    }

}
