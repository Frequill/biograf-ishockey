package basePackage.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Repository
public class AddScreeningDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void addScreenings(String title, String studio, String screening_date, String saloon){
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("add_screening");
		
		Map<String, String> inParameters = new HashMap<>();
		
		/*
		inParameters.put("title", title);
		inParameters.put("studio", studio);
		inParameters.put("screening_date", screening_date);
		inParameters.put("saloon", saloon);
		
		SqlParameterSource in = new MapSqlParameterSource(inParameters);
	
		 */
		
		simpleJdbcCall.execute(title, studio, screening_date, saloon);
		
	}

}
