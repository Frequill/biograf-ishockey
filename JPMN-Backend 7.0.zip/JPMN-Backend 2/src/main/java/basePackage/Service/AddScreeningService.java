package basePackage.Service;

import basePackage.Dao.AddScreeningDao;
import basePackage.dataBaseClasses.Upcomming_screening;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddScreeningService {
	
	@Autowired
	AddScreeningDao addScreeningDao;
	
	public void addScreening(String title, String studio, String screening_date, String saloon){
		addScreeningDao.addScreenings(title, studio, screening_date, saloon);
	}
}
