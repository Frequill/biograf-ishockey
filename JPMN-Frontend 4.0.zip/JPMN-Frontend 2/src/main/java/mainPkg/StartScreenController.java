package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class StartScreenController extends GUI {

    //Action-listeners for the "start screen", the first GUI the user sees upon boot-up...

    @FXML
    void quitProgram(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void showAdminScene(ActionEvent event) {
        try {launchAdminScene();} catch (IOException e) {e.printStackTrace();} // Try-Catch required to use JAVAFX scene-switch
    }
    @FXML
    void showCustomerScene(ActionEvent event) {
    
    }
    
    @FXML
    void testConnection(ActionEvent event) {
        ConnectionManager connectionManager = new ConnectionManager();
        String answer = connectionManager.sendRequest("hello/?name="+ "patrik");
        System.out.println(answer);
    }
}