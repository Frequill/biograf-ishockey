package mainPkg;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class StaffScreenController extends GUI{
    
    @FXML
    private TextField IdInputField;
    
    @FXML
    private Label staffPrintOutLabel;
    
    @FXML
    void addShift(ActionEvent event) {
    
    }
    
    @FXML
    void addStaff(ActionEvent event) {
    
    }
    
    @FXML
    void deleteStaffById(ActionEvent event) {
    
    }
    //BEHÖVER HJÄLP MED DENNA. SÄGER ATT VI BEHÖVER SKICKA EN STRÄNG OCH INTE EN
    //ARRAYLIST?!?!?! DEN FÅR STRÄNGAR
    @FXML
    void getAllStaff(ActionEvent event) {
        ConnectionManager connectionManager = new ConnectionManager();
        String answer = connectionManager.sendRequest("getAllStaff/?allStaff=");
        staffPrintOutLabel.setText(answer);
    }
    
    @FXML
    void getStaffById(ActionEvent event) {
        String usersId = IdInputField.getText();
        ConnectionManager connectionManager = new ConnectionManager();
        String answer = connectionManager.sendRequest("getStaffByID/?staff_ID="+ usersId);
        //System.out.println("TESTTTTTT\n" + answer);
        staffPrintOutLabel.setText(answer);
    }
    
    @FXML
    void goToAdminscreen(ActionEvent event) {
        try {launchAdminScene();} catch (IOException e) {e.printStackTrace();}
    }
    
}
