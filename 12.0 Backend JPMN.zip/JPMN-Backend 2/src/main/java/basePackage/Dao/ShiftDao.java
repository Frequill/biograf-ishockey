package basePackage.Dao;

import basePackage.dataBaseClasses.Shift;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class ShiftDao extends JdbcDaoSupport
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}
	
	public List<Shift> getAllShifts() {
		String query = "SELECT * FROM shifts";
		
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
		List<Shift> shiftList = new ArrayList<>();
		
		for (Map<String, Object> row : rows) {
			Shift shift = new Shift(Integer.parseInt(row.get("shift_ID").toString()),
					(Integer.parseInt(row.get("staff_ID").toString())),
					(String) row.get("start_time"),
					(String) row.get("end_time"));
			shiftList.add(shift);
		}
		return shiftList;
	}
	
}
