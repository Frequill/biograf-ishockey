package basePackage.Service;

import basePackage.Dao.AddScreeningDao;
import basePackage.Dao.AddShiftDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddShiftService {
	
	@Autowired
	AddShiftDao addShiftDao;
	
	public void addShift(String shift_ID, String start_time, String end_time){
		addShiftDao.addShift(shift_ID, start_time, end_time);
	}
}