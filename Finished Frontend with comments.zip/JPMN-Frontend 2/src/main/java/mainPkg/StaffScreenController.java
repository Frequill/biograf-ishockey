package mainPkg;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.io.IOException;

public class StaffScreenController extends GUI{
    
    // Controller class for the "Start Screen"
    
    @FXML
    private TextField IdInputField;
    
    @FXML
    private TextField deleteField;

    @FXML
    private TextArea staffInfoTextField;


    /**
     Takes user to "Add-shift screen"
     */
    @FXML
    void addShift(ActionEvent event) {
        try{launchAddShiftScene();} catch (IOException e) {e.printStackTrace();}
    }

    /**
     Takes user to "Add-staff screen"
     */
    @FXML
    void addStaff(ActionEvent event) throws IOException {
        launchAddStaffScene();
    }
    
    /**
     A button that deletes staff from the database based on which staff_Id is entered into the text field
     */
    @FXML
    void deleteStaffById(ActionEvent event) {
        String usersId = deleteField.getText();
        ConnectionManager connectionManager = new ConnectionManager();
        connectionManager.sendDeleteRequest("deleteStaffById?s_ID="+ usersId);
    }
    
    /**
     A button that gets all the staff from the database and displays them so that it's easier to read
     */
    @FXML
    void getAllStaff(ActionEvent event) {
        ConnectionManager connectionManager = new ConnectionManager();
        String answers = connectionManager.sendRequest("getAllStaff");

        String firstAnswers = answers.replace("},", "}\n\n");
        String secondAnswers = firstAnswers.replace("[", " ");
        String thirdAnswers = secondAnswers.replace("]", "");
        String finalScreenings = thirdAnswers.replace("saloon", "\nsaloon");

        staffInfoTextField.setText(finalScreenings);
    }
    /**
     A button that gets a single staff member based on their staff_ID
     */
    @FXML
    void getStaffById(ActionEvent event) {
        String usersId = IdInputField.getText();
        ConnectionManager connectionManager = new ConnectionManager();
        String answer = connectionManager.sendRequest("getStaffByID/?staff_ID="+ usersId);

        staffInfoTextField.setText(answer);
    }
    
    /**
     Button takes user to customer screen when they press "Tillbaka" from main menu
     */
    @FXML
    void goToAdminScreen(ActionEvent event) {
        try {launchAdminScene();} catch (IOException e) {e.printStackTrace();}
    }
    
}
