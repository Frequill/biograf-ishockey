package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CustomerScreenController extends GUI {
	
	// Controller class for the "Start Screen"
	
	@FXML
	private TextField existingUserLoginTextField;
	
	@FXML
	private PasswordField existingUserPWTextField;
	
	@FXML
	private TextField newUserCreditcardTextField;
	
	@FXML
	private TextField newUserEmailTextField;
	
	@FXML
	private TextField newUserNameTextField;
	
	@FXML
	private PasswordField newUserPWTextField;
	
	@FXML
	private Label existingUserConfirmedLabel1;
	
	@FXML
	private Label newUserConfirmedLabel;
	
	@FXML
	private Label logInErrorMsgLabel;
	
	/**
	 A button that lets the user enter their new account information and create a new account. If the account already exists
	 an error message is displayed, otherwise a new account is created and added to the database
	 */
	@FXML
	void createNewUser(ActionEvent event) {
		String newUserNameInput = newUserNameTextField.getText().replace(" ", "WHITESPACEHEREX");
		String newUserEmailInput = newUserEmailTextField.getText().replace(" ", "WHITESPACEHEREX");
		String newUserCreditcardInput = newUserCreditcardTextField.getText().replace(" ", "WHITESPACEHEREX");
		String newUserPWInput = newUserPWTextField.getText().replace(" ", "WHITESPACEHEREX");

		ConnectionManager connectionManager = new ConnectionManager();
		String answer = connectionManager.sendRequest("compareCustomerEmail/?email=" + newUserEmailInput);
		System.out.println("This is in answer: " + answer);

		if (answer.equals("[]")){
			connectionManager.sendRequest("addCustomer/?valuesAsCSV=" + "," + newUserNameInput + "," + newUserEmailInput + "," + newUserCreditcardInput + "," + newUserPWInput);
			newUserConfirmedLabel.setText("Användaren har lagts till i systemet!");
		} else {
			newUserConfirmedLabel.setText("Den inmatade email-adressen finns redan i systemet...");
		}
	}
	
	/**
	 A button that allows customers that already have an account to log in. Uses a stored procedure called "verify_customer" to check if
	 the entered email is in the database, and if the password matches the email address in the database. If the email address is wrong
	 the customer is told so, and if the password doesn't match a different error message is shown.
	 */
	@FXML
	void existingUserLogin(ActionEvent event) throws IOException {
		String existingUserEmailInput = existingUserLoginTextField.getText().replace(" ", "WHITESPACEHEREX");
		String existingUserPWInput = existingUserPWTextField.getText().replace(" ", "WHITESPACEHEREX");
		
		ConnectionManager connectionManager = new ConnectionManager();
		connectionManager.sendRequest("verify_customer/?valuesAsCSV=" + "," + existingUserEmailInput + "," + existingUserPWInput);
		
		String answer = connectionManager.sendRequest("getLastValidationNumber");

		String finalAnswer = String.valueOf(answer.charAt(14));
		
		System.out.println("THIS " + finalAnswer);
		
		if(finalAnswer.equals("2")){
			setCurrentUser(existingUserEmailInput);
			launchLoggedInUser();
		} else if (finalAnswer.equals("1")){
			logInErrorMsgLabel.setText("Felaktigt lösenord!");
		} else {
			logInErrorMsgLabel.setText("Användaren existerar inte!");
		}
	}
	
	/**
	 A button to go back to the previous screen
	 */
	@FXML
	void goToStartScreen(ActionEvent event) throws IOException {
		launchStartScene();
	}
}
