package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AdminScreenController extends GUI {
    
    // Controller class for the "Start Screen"
    
    @FXML
    private TextArea displayAllSaloons;
    
    @FXML
    private TextField saloonNameTextField;
    
    @FXML
    private TextField saloonSeatsTextField;
    
    @FXML
    private TextField saloon_idTextField;
    
    @FXML
    private Label saloonRemovedMsg;
    
    /**
     A button that takes the user to the addMovie screen
     */
    @FXML
    void addMovie(ActionEvent event) throws IOException {
        launchMovieScene();
    }
    
    /**
     A button that lets the user add a new saloon by entering its name and the number of seats and displays a message
     telling the user which saloon has been added
     */
    @FXML
    void addSaloon(ActionEvent event) {
        String saloonNameInput = saloonNameTextField.getText();
        String seatsInput = saloonSeatsTextField.getText();
    
        ConnectionManager connectionManager = new ConnectionManager();
        String answer = connectionManager.sendRequest("addSaloon/?valuesAsCSV=" + "," + saloonNameInput + "," + seatsInput);
    
        displayAllSaloons.setText("Saloon: " + saloonNameInput + " has been added!");
    }
    
    /**
     A button that lets the user delete a saloon based on which saloon_ID is entered and displays a message
     telling the user which saloon has been removed
     */
    @FXML
    void deleteSaloon(ActionEvent event) {
        String saloon_IDInput = saloon_idTextField.getText();
        ConnectionManager connectionManager = new ConnectionManager();
        connectionManager.sendDeleteRequest("deleteSaloonByID?saloon_ID="+ saloon_IDInput);
        
        saloonRemovedMsg.setText("Saloon with ID: " + saloon_IDInput + " has been removed!");
    }
    
    /**
     A button to go the staff screen
     */
    @FXML
    void goToStaffScreen(ActionEvent event) {
        try {
            launchStaffScene();}catch (IOException e) {e.printStackTrace();}
    }
    
    /**
     A button to go back to the start screen
     */
    @FXML
    void goToStartScreen(ActionEvent event) {
        try {
            launchStartScene();} catch (IOException e) {e.printStackTrace();}
    }
    
    /**
     A button to display all the saloons from the database in a way that is easier to read
     */
    @FXML
    void getAllSaloons(ActionEvent event) {
        ConnectionManager connectionManager = new ConnectionManager();
        String answers = connectionManager.sendRequest("getAllSaloons");

        String firstAllSaloons = answers.replace("},", "}\n\n");
        String secondAllSaloons = firstAllSaloons.replace("[", " ");
        String thirdAllSaloons = secondAllSaloons.replace("]", "");
        String finalAllSaloons = thirdAllSaloons.replace("saloon", "\nsaloon");

        displayAllSaloons.setText(finalAllSaloons);
    }

}
