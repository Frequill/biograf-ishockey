package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddShiftScreenController extends GUI {
	
	// Controller class for the "Start Screen"
	
	@FXML
	private TextField staff_IDTextField;
	
	@FXML
	private TextField endTimeTextField;
	
	@FXML
	private TextField startTimeTextField;
	
	@FXML
	private TextField shiftIDTextField;
	
	@FXML
	private Label shiftRemovedMsg;
	
	@FXML
	private Label shiftAddedMsg;

	@FXML
	private TextArea displayAllShifts;
	
	
	/**
	 A button that deletes a shift from the database based on which shift_ID was entered
	 */
	@FXML
	void confirmRemove(ActionEvent event) {
		String shift_IDDeleteInput = shiftIDTextField.getText();
		ConnectionManager connectionManager = new ConnectionManager();
		connectionManager.sendDeleteRequest("deleteShiftByID?shift_ID="+ shift_IDDeleteInput);
		
		shiftRemovedMsg.setText("Shift with ID: " + shift_IDDeleteInput + " has been removed!");
	}
	
	/**
	 A button that lets the user add a new shift to the database uses the stored procedure add_shift from the database
	 */
	@FXML
	void confirmInput(ActionEvent event) {
		
		String staff_IDInput = staff_IDTextField.getText().replace(" ", "WHITESPACEHEREX");
		String startTimeInput = startTimeTextField.getText().replace(" ", "WHITESPACEHEREX");
		String endTimeInput = endTimeTextField.getText().replace(" ", "WHITESPACEHEREX");
		
		ConnectionManager connectionManager = new ConnectionManager();
		connectionManager.sendRequest("addShift/?valuesAsCSV=" + "," + staff_IDInput + "," + startTimeInput + "," +  endTimeInput);
		
		shiftAddedMsg.setText("Shift has been added!");
	}
	
	/**
	 A button that makes you go back to the staff screen
	 */
	@FXML
	void goToStaffScreen(ActionEvent event) {
		{try{launchStaffScene();} catch (IOException e) {e.printStackTrace();}}
	}
	
	/**
	 A button that displays all the shifts from the database in a way that is easier to read
	 */
	@FXML
	void showAllShifts(ActionEvent event) {
		ConnectionManager connectionManager = new ConnectionManager();
		String answers = connectionManager.sendRequest("getAllShifts");
		
		String finalAnswers = answers.replace("'}," , "\n\n");
		
		displayAllShifts.setText(finalAnswers);
	}
	
}
