package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddShiftScreenController extends GUI {
	
	@FXML
	private TextField endTimeTextField;
	
	@FXML
	private TextField staff_idTextField;
	
	@FXML
	private TextField startTimeTextField;
	
	
	@FXML
	void confirmInput(ActionEvent event) {
			String staff_idInput = staff_idTextField.getText();
			String startTimeInput = startTimeTextField.getText();
			String endTimeInput = endTimeTextField.getText();
			
			ConnectionManager connectionManager = new ConnectionManager();
			String answer = connectionManager.sendRequest("addShift/?valuesAsCSV=" + "," + staff_idInput + "," + startTimeInput + ","+  endTimeInput);
			System.out.println(answer);
	}
	
	@FXML
	void goToStaffScreen(ActionEvent event) {
		{try{launchStaffScene();} catch (IOException e) {e.printStackTrace();}}
	}
	
	@FXML
	void showAllShifts(ActionEvent event) {
	
	}
	
}
