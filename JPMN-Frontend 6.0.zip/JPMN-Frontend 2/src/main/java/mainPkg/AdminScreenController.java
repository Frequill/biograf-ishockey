package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class AdminScreenController extends GUI {

    @FXML
    void addMovie(ActionEvent event) throws IOException {
        launchMovieScene();
    }

    @FXML
    void addSaloon(ActionEvent event) {

    }

    @FXML
    void deleteSaloon(ActionEvent event) {

    }

    @FXML
    void goToStaffScreen(ActionEvent event) {
        try {
            launchStaffScene();}catch (IOException e) {e.printStackTrace();}
    }

    @FXML
    void goToStartScreen(ActionEvent event) {
        try {goToStartScene();} catch (IOException e) {e.printStackTrace();}
    }

}
