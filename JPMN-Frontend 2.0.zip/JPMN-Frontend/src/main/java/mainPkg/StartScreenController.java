package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class StartScreenController extends GuI {

    @FXML
    void quitProgram(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void showAdminScene(ActionEvent event) {
        try {goToAdminScene();} catch (IOException e) {e.printStackTrace();} // Try-Catch required to use JAVAFX scene-switch
    }
    @FXML
    void showCustomerScene(ActionEvent event) {

    }
}