package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class AdminScreenController extends GuI {

    @FXML
    void addMovie(ActionEvent event) {

    }

    @FXML
    void addSaloon(ActionEvent event) {

    }

    @FXML
    void deleteSaloon(ActionEvent event) {

    }

    @FXML
    void goToStaffScreen(ActionEvent event) {

    }

    @FXML
    void goToStartScreen(ActionEvent event) {
        try {goToStartScene();} catch (IOException e) {e.printStackTrace();}
    }

}
