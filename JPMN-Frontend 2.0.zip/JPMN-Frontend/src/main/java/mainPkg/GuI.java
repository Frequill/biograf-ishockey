package mainPkg;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class GuI extends Application {

    private static Stage mainStage;

    public void goToStartScene() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(GuI.class.getResource("StartScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load());

        mainStage.setTitle("startScreen");
        mainStage.setScene(scene);
        mainStage.show();
    }

    public void goToAdminScene() throws IOException {
        mainStage.setTitle("AdminScreen");

        FXMLLoader fxmlLoader = new FXMLLoader(GuI.class.getResource("AdminScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load());

        mainStage.setScene(scene);
        mainStage.show();
    }



    @Override
    public void start(Stage primaryStage) throws IOException {
        mainStage = primaryStage;

        FXMLLoader fxmlLoader = new FXMLLoader(GuI.class.getResource("StartScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load());

        mainStage.setTitle("StartScreen");
        mainStage.setScene(scene);
        mainStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
