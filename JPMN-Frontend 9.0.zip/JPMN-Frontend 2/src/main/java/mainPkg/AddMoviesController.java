package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddMoviesController extends GUI {
	
	@FXML
	private TextField saloonTextField;
	
	@FXML
	private TextField screeningdateTextField;
	
	@FXML
	private TextField studioTextField;
	
	@FXML
	private TextField titleTextField;
	
	@FXML
	void confirmMovie(ActionEvent event) {
		// Replaces spaces with the phrase "WHITESPACEHEREX" to fix an annoying bug where program would refuse to take in spaces as a request-parameter...
		String moveTitle = titleTextField.getText().replace(" ", "WHITESPACEHEREX");
		String studio = studioTextField.getText().replace(" ", "WHITESPACEHEREX");
		String screeningdate = screeningdateTextField.getText().replace(" ", "WHITESPACEHEREX");
		String saloon = saloonTextField.getText().replace(" ", "WHITESPACEHEREX");

		
		ConnectionManager connectionManager = new ConnectionManager();
		String answer = connectionManager.sendRequest("addScreening/?valuesAsCSV=" + "," + moveTitle + "," + studio + ","+  screeningdate + "," + saloon);
		System.out.println("answer: " + answer);
	}
	
	@FXML
	void goToAdminScreen(ActionEvent event) throws IOException {
		launchAdminScene();
	}
	
}
