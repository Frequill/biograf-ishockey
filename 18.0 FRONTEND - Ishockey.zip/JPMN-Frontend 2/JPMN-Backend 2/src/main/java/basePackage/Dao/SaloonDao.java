package basePackage.Dao;

import basePackage.dataBaseClasses.Saloon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class SaloonDao
{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<Saloon> getAllSaloons() {
		String query = "SELECT * FROM saloons";
		
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
		List<Saloon> saloonList = new ArrayList<>();
		
		for (Map<String, Object> row : rows) {
			Saloon saloon = new Saloon(Integer.parseInt(row.get("saloon_ID").toString()),
					(String) row.get("saloon_name"),
					(int) row.get("seats"));
			saloonList.add(saloon);
		}
		return saloonList;
	}
	
}
