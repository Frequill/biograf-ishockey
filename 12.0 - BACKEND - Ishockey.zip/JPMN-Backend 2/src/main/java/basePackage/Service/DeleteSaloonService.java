package basePackage.Service;

import basePackage.Dao.DeleteSaloonDao;
import basePackage.Dao.DeleteStaffDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeleteSaloonService
{
	@Autowired
	DeleteSaloonDao deleteSaloonDao;
	
	public void deleteSaloon(String saloonID){
		deleteSaloonDao.delete_saloon(saloonID);
	}
}
