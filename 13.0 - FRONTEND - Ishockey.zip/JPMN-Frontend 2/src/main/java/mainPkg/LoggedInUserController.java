package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import java.io.IOException;

public class LoggedInUserController extends GUI {
	
	@FXML
	private Label userGreetingLabel;
	
	@FXML
	private TextArea showMyBookings;
	
	public void initialize() {
		userGreetingLabel.setText("Current profile: " + getCurrentUser());
	}
	
	@FXML
	void goToCustomerScreen(ActionEvent event) throws IOException {
		launchCustomerScene();
	}
	
	@FXML
	void deleteUserBooking(ActionEvent event) {
		
	}
	
	@FXML
	void goToBookTicketScreen(ActionEvent event) throws IOException {
		launchBookTicketsScene();
	}
	
	@FXML
	void showUsersBookings(ActionEvent event) {
		ConnectionManager connectionManager = new ConnectionManager();
		
		String user_ID = connectionManager.sendRequest("getUser_ID/?userEmailAddress=" + getCurrentUser());
		String finalUser_ID = String.valueOf(user_ID.charAt(29));
		
		String fullList = connectionManager.sendRequest("getMyBookings/?user_ID=" + finalUser_ID);
		
		String finalFullList = fullList.replace("}" , "\n\n");
		System.out.println(finalFullList);

		if (finalFullList.equals("[]")){
			String emptyResult = finalFullList.replace("[]", "You have no current bookings...");
			showMyBookings.setText(emptyResult);
		} else{
			showMyBookings.setText(finalFullList);
		}
		

		
	}
}
