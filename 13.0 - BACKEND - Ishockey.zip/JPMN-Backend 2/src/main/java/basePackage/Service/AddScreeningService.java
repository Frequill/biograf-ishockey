package basePackage.Service;

import basePackage.Dao.AddScreeningDao;
import basePackage.dataBaseClasses.Staff;
import basePackage.dataBaseClasses.Upcomming_screening;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class AddScreeningService {
	
	@Autowired
	AddScreeningDao addScreeningDao;
	
	public void addScreening(String title, String studio, String screening_date, String saloon){
		
		addScreeningDao.addScreenings(title, studio, screening_date, saloon);
	}
	
	public ArrayList<Upcomming_screening> getAllScreenings(){
		return (ArrayList<Upcomming_screening>) addScreeningDao.getAllScreenings();
	}
	
	public void deleteScreeningById(String movie_ID){
		addScreeningDao.deleteScreeningById(movie_ID);
	}
}