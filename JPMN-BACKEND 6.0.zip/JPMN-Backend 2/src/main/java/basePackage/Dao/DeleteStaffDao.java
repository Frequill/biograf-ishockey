package basePackage.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class DeleteStaffDao
{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public String delete_staff(int s_ID){
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("delete_staff");
		
		Map<String, String> inParameters = new HashMap<>();
		
		inParameters.put("staff_ID", String.valueOf(s_ID));
		
		SqlParameterSource in = new MapSqlParameterSource(inParameters);
		
		simpleJdbcCall.execute(in);
		
		return String.valueOf(s_ID);
		
	}
}
