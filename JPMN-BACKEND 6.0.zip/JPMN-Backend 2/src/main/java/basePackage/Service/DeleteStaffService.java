package basePackage.Service;

import basePackage.Dao.DeleteStaffDao;
import org.springframework.stereotype.Service;

@Service
public class DeleteStaffService
{
	DeleteStaffDao deleteStaffDao;
	
	public String deleteStaff(int s_ID){
		return deleteStaffDao.delete_staff(s_ID);
		
	}
}
