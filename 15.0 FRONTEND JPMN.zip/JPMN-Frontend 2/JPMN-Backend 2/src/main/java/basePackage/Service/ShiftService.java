package basePackage.Service;

import basePackage.Dao.AddShiftDao;
import basePackage.Dao.ShiftDao;
import basePackage.dataBaseClasses.Saloon;
import basePackage.dataBaseClasses.Shift;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ShiftService
{
	@Autowired
	ShiftDao shiftDao;
	
	public ArrayList<Shift> getAllShifts(){return (ArrayList<Shift>) shiftDao.getAllShifts();
	}
}
