package basePackage.Service;

import basePackage.Dao.DeleteSaloonDao;
import basePackage.Dao.DeleteShiftDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeleteShiftService
{
	@Autowired
	DeleteShiftDao deleteShiftDao;
	
	public void deleteShift(String shiftID){
		deleteShiftDao.delete_shift(shiftID);
	}
}
