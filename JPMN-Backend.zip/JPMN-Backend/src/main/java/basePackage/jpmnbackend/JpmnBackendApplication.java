package basePackage.jpmnbackend;

import basePackage.Service.CustomerService;
import basePackage.dataBaseClasses.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;

import java.sql.ResultSet;

@SpringBootApplication
@ComponentScan(basePackages = "basePackage")

@RestController
public class JpmnBackendApplication {

    @Autowired
    CustomerService customerService;

    public static void main(String[] args) {
        //SpringApplication.run(JpmnBackendApplication.class, args);
        
        ApplicationContext context = SpringApplication.run(JpmnBackendApplication.class, args);
        CustomerService customerService = context.getBean(CustomerService.class);
        System.out.println(customerService.getCustomerById(1));
       
       
        //Försök att stoppa in en ny customer
        //Customer Arnold = new Customer(5,"'Arnold Schwarzenegger'", "'bigaustiraman@fatgains.com'", "'5663378744005202'", "12'", "'24'");
        //customerService.insertCustomer(Arnold);
        
        
        //fel import, ändrade till Spring
        //.getBean gav error tills jag prövade de olika
        //context.getBean(Class<T>, object.. objects )
        
    
        //System.out.println(customerService.getCustomerById(1));
        
        /*
        SpringApplication.run(JpmnBackendApplication.class, args);
    
        CustomerService customerService = SpringApplication.run(JpmnBackendApplication.class, args).getBean(CustomerService.class);
        //CustomerService customerService = context.getBean(CustomerService.class);

        Customer Arnold = new Customer(2,"Arnold Schwarzenegger", "bigaustiraman@fatgains.com", "5663378744005202", "12", "12");
        //customerService.insertCustomer(Arnold);
        //System.out.println(customerService.;);
        
        customerService.getCustomerById(2);
        System.out.println(customerService.getCustomerById(2));


        // Problemet nu: Våran syntax är säkert fel, exakt hur fixar vi våran DAO klass?

        // Få våra stored procedures i MySQL att nås från IntelliJ
        // Hur vet vi ifall application.properties fungerar?
        */
    }

}
