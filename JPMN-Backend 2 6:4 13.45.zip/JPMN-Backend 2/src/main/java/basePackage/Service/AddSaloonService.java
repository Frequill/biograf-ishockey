package basePackage.Service;
import basePackage.Dao.AddSaloonDao;
import basePackage.dataBaseClasses.Saloon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddSaloonService
{
	@Autowired
	AddSaloonDao addSaloonDao;
	
	public void addSaloon(String saloon_name, String seats){
		addSaloonDao.addSaloon(saloon_name, seats);
	}
}
