package basePackage.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class DeleteStaffDao
{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void delete_staff(String s_ID){
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("delete_staff");
		
		Integer s_IDToInt = Integer.parseInt(s_ID);
		
		simpleJdbcCall.execute(s_IDToInt);
	}
}
