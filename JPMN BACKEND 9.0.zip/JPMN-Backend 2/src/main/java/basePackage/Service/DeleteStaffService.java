package basePackage.Service;

import basePackage.Dao.DeleteStaffDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeleteStaffService
{
	@Autowired
	DeleteStaffDao deleteStaffDao;
	
	public void deleteStaff(String s_ID){
		deleteStaffDao.delete_staff(s_ID);
	}
}
