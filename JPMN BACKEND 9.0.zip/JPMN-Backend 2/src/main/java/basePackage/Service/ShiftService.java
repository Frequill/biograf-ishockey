package basePackage.Service;

import basePackage.Dao.ShiftDao;
import basePackage.dataBaseClasses.Shift;
import org.springframework.beans.factory.annotation.Autowired;

public class ShiftService
{
	@Autowired
	ShiftDao shiftDao;
	
	public void addShift(Shift shift){
		shiftDao.addShift(String.valueOf(shift.getStaff_ID()), shift.getStart_time(), shift.getEnd_time());
	}
}
