package mainPkg;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class StaffScreenController {

    @FXML
    private Button addShift;

    @FXML
    private Button addStaff;

    @FXML
    private Button deleteStaffById;

    @FXML
    private Button getAllStaff;

    @FXML
    private Button getStaffById;

}
