package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class StartScreenController {

    @FXML
    void quitProgram(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void showAdminScene(ActionEvent event) {

    }

    @FXML
    void showCustomerScene(ActionEvent event) {

    }
}
