package mainPkg;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class AdminScreenController {

    @FXML
    void addMovie(ActionEvent event) {

    }

    @FXML
    void addSaloon(ActionEvent event) {

    }

    @FXML
    void deleteSaloon(ActionEvent event) {

    }

    @FXML
    void goToStaffScreen(ActionEvent event) {

    }

    @FXML
    void goToStartScreen(ActionEvent event) {

    }

}
