package basePackage.Dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;

class ScreeningDaoTest {

    @Mock
    ScreeningDao screeningDaoMock;

    @BeforeEach
    void setup(){
        MockitoAnnotations.openMocks(this); // Injecta mocken från denna klass
    }

    @Test
    void restoreTickets() {
        // Setup
        String works = "works"; // String I want returned from delete_order
        Mockito.when(screeningDaoMock.restoreTickets("1", "1")).thenReturn(works);

        // Action
        String fakeResult = screeningDaoMock.restoreTickets("1", "1");

        // Result
        assertEquals(works, fakeResult);

        System.out.println("Expected: " + works + "      Actual result: " + fakeResult);
    }
}