package basePackage.Dao;

import basePackage.dataBaseClasses.Customer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CustomerDaoTest {

    @Mock
    JdbcTemplate jdbcTemplateMock;

    @Mock
    CustomerDao customerDaoMock;


    @Mock
    Customer customerMock = new Customer(04, "Janne", "janne@mail.se", "salt1", "5226641377985525", "salt2");

    @Mock
    List<Customer> customerListMock = new ArrayList<>();

    @BeforeEach
    void setup(){
        MockitoAnnotations.openMocks(this); // Injecta mocken från denna klass
    }

    @Test
    void insertCustomer() {
        // Setup
        String query = "INSERT INTO customers(customer_name, customer_email, salt1, creditcard_number, salt2) VALUES (?, ?, ?, ?, ?)";
        Mockito.when(jdbcTemplateMock.update(query,"Janne", "janne@mail.se", "salt1", "5226641377985525", "salt2")).thenReturn(1);

        // Action
        int i = jdbcTemplateMock.update(query, "Janne", "janne@mail.se", "salt1", "5226641377985525", "salt2");

        // Result
        assertEquals(1, i);
        Mockito.verify(jdbcTemplateMock).update(query,"Janne", "janne@mail.se", "salt1", "5226641377985525", "salt2");

        System.out.println("Expected: " + 1 + " Result: " + i); // Output
    }

    @Test
    void getCustomerById() {
        // Setup
        Mockito.when(customerDaoMock.getCustomerById(Mockito.anyString())).thenReturn(customerMock);

        // Action
        Customer e = customerDaoMock.getCustomerById("Banan");

        // Result
        assertEquals(customerMock, e);
        Mockito.verify(customerDaoMock).getCustomerById("Banan");

        System.out.println("Expected: " + customerMock + " Result: " + e); // Output
    }

    @Test
    void getAllCustomers() {
        // Setup
        Mockito.when(customerDaoMock.getAllCustomers()).thenReturn(customerListMock);

        // Action
        List<Customer> testList = customerDaoMock.getAllCustomers();

        // Result
        assertEquals(customerListMock, testList);

        System.out.println("Expected: " + customerListMock + " Now showing testList: --> " + testList + " <--  If testList showed \"customerListMock\" then test was successful!" + ""); // Output
    }

    @Test
    void addCustomer() {
        // Setup
        Map<String, Object> testMap = new HashMap<>();
        // Decided to fill map with letter "A" and the Mocked "customer" object for clearer testing.
        testMap.put("A", customerMock);
        Mockito.when(customerDaoMock.addCustomer("Arne", "arne@mail.se", "5887741233635224", "password")).thenReturn(testMap);

        // Action
        Map fakeMap = customerDaoMock.addCustomer("Arne", "arne@mail.se", "5887741233635224", "password");

        // Result
        assertEquals(testMap, fakeMap);

        System.out.println("Expected: " + testMap + "Actual result: " + fakeMap);
    }

    @Test
    void existingUserLogin() {
    }

    @Test
    void getValidationNumber() {
        // Setup
        Mockito.when(customerDaoMock.getValidationNumber()).thenReturn("1");

        // Action
        String fakeValidationNumber = customerDaoMock.getValidationNumber();

        // Result
        assertEquals(customerDaoMock.getValidationNumber(), fakeValidationNumber);

        System.out.println("Expected: " + customerDaoMock.getValidationNumber() + " actual result: " + fakeValidationNumber); // Output
    }

    @Test
    void getCustomerIDByEmail() {
    }

    @Test
    void getIndividualBookings() {
        // Setup
        String user_ID = "ABC";
        Mockito.when(customerDaoMock.getIndividualBookings(user_ID)).thenReturn("Right");

        // Action
        String result = customerDaoMock.getIndividualBookings(user_ID);

        // Result
        assertEquals("Right", result);

        System.out.println("Expected: " + "Right  Result: " + result);
    }

    @Test
    void bookTickets() {
    }

    @Test
    void delete_order() {
    }
}