package basePackage.jpmnbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpmnBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
