package basePackage.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

@Repository
public class DeleteShiftDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void delete_shift(String shiftID){
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("delete_shift");
		
		Integer shiftIDToInt = Integer.parseInt(shiftID);
		
		simpleJdbcCall.execute(shiftIDToInt);
	}
}
